/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.projetopi.projetopi;

import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.Timestamp;

import java.util.Arrays;

/**
 *
 * @author Matheus
 */
public class DaoProduto {

    private Connection obterConexao()
            throws ClassNotFoundException, SQLException {
        Connection conn = null;

        // Passo 1: Registrar driver JDBC
        Class.forName("com.mysql.jdbc.Driver");
        // Passo 2: Obter a conexao
        conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/produtobd",
                "root",
                "");
        return conn;
    }

    public void inserir(Produto produto) throws SQLException, Exception {
        //Monta a string de inserção de um produto no BD,
        //utilizando os dados do produto passados como parâmetro
        String sql = "INSERT INTO produtobd.produto(NOME, DESCRICAO, PRECO_COMPRA, PRECO_VENDA, QUANTIDADE, DT_CADASTRO) VALUES (?, ?, ?, ?, ?, ?)";
        String sql2 = "INSERT INTO produtobd.categoria(NOME) VALUES (?)";
        String sql3 = "INSERT INTO produtobd.produto_categoria(ID_PRODUTO, ID_CATEGORIA) VALUES(?,?)";

        try (Connection conn = obterConexao()) {
            conn.setAutoCommit(false);
            try (
                    PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                    PreparedStatement stmt2 = conn.prepareStatement(sql2, Statement.RETURN_GENERATED_KEYS);
                    PreparedStatement stmt3 = conn.prepareStatement(sql3);) {

                stmt.setString(1, produto.getNome());
                stmt.setString(2, produto.getDescricao());
                stmt.setDouble(3, produto.getPrecoCompra());
                stmt.setDouble(4, produto.getPrecoVenda());
                stmt.setInt(5, produto.getQuantidade());
                stmt.setTimestamp(6, new Timestamp(produto.getData().getTime()));
                stmt.execute();

                ResultSet generatedKeysProd = stmt.getGeneratedKeys();
                int idProduto=0;
                if (generatedKeysProd.next()) {
                    idProduto = generatedKeysProd.getInt(1);
                }

                String cat = "";

                for (int i = 0; i < produto.getCategorias().length; i++) {

                    cat = cat + " " + produto.getCategorias()[i];
                }
                stmt2.setString(1, cat);
                stmt2.execute();
                
                ResultSet generatedKeysCat = stmt2.getGeneratedKeys();
                int idCategoria=0;
                if(generatedKeysProd.next()){
                    idCategoria = generatedKeysProd.getInt(1);
                }
                
                stmt3.setInt(1, idProduto);
                stmt3.setInt(2, idCategoria);
                stmt3.execute();
                
                conn.commit();

            }
            
        }catch (SQLException ex) {
           
            System.out.println(ex.getLocalizedMessage());
            
        }
    }
}
